This addon is for raspberry pi ONLY!
It just runs vcgencmd from raspberry pi firmware to turn off hdmi power
and force the display to go to standby mode.

It was @popcornmix who inspired me to write this little script.

Addon skeleton, some code and screensaver-black.png were shamelessly borrowed
from https://github.com/XBMC-Addons/screensaver.picture.slideshow .
